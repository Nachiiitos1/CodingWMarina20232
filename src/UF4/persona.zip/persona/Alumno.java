package UF4.persona;

public class Alumno extends Personas {
    private String curs;
    private String assignatures;
    private String escola;
    private String notes;
}
