package UF4.persona;

public class MainPersonas {
    public static void main(String[] args) {
        Personas p = new Personas();
        Alumno a = new Alumno();
    }
}
