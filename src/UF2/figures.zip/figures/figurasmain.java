package UF2.figures;

public class figurasmain {
    public static void main(String[] args){
        Rectangle rectangulo = new Rectangle();
        /*Rectangle rectangulo2 = new Rectangle(5,3,"verde");
        Rectangle rectangulo3 = new Rectangle(4,6,"rosa");*/

        Circulo circulo1 = new Circulo(2.5,"azul");
        Cuadrado cuadrado1 = new Cuadrado(3,3,"rojo");
        Triangulo triangulo1= new Triangulo(4,4,3,"verde");

    }
}
