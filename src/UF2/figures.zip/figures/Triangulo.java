package UF2.figures;

public class Triangulo {
    public int costado1;
    public int costado2;
    public int costado3;

    public String color;

    public Triangulo(int a, int b, int c, String d) {
        costado1 = a;
        costado2 = b;
        costado3 = c;
        color = d;
    }
}
