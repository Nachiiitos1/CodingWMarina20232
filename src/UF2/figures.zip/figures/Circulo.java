package UF2.figures;

public class Circulo {
    public double radio;
    public String color;

    public Circulo(double a, String b ){
        radio=a;
        color=b;
    }
}
