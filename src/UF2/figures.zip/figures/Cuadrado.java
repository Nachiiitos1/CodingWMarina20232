package UF2.figures;

public class Cuadrado {
    public int base;
    public int altura;
    public String color;

    public Cuadrado(int a, int b, String c){
        base=a;
        altura=b;
        color=c;
    }
}
